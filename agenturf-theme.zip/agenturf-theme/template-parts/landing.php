<?php
/** Landing visiteur : hero vidéo + outils + porte Google. */
$login = agenturf_login_url();
$race  = agenturf_race_data();
$meta  = $race['meta'];
$nb    = count( $race['horses'] );
$nbsc  = count( $race['scenarios'] );
$google_svg = '<svg viewBox="0 0 48 48" aria-hidden="true"><path fill="#FFC107" d="M43.6 20.1H42V20H24v8h11.3C33.7 32.7 29.2 36 24 36c-6.6 0-12-5.4-12-12s5.4-12 12-12c3.1 0 5.9 1.2 8 3l5.7-5.7C34.2 6.1 29.3 4 24 4 13 4 4 13 4 24s9 20 20 20 20-9 20-20c0-1.3-.1-2.6-.4-3.9z"/><path fill="#FF3D00" d="M6.3 14.7l6.6 4.8C14.7 15.1 19 12 24 12c3.1 0 5.9 1.2 8 3l5.7-5.7C34.2 6.1 29.3 4 24 4 16.3 4 9.7 8.3 6.3 14.7z"/><path fill="#4CAF50" d="M24 44c5.2 0 9.9-2 13.4-5.2l-6.2-5.2C29.2 35.1 26.7 36 24 36c-5.2 0-9.6-3.3-11.3-8l-6.5 5C9.6 39.6 16.2 44 24 44z"/><path fill="#1976D2" d="M43.6 20.1H42V20H24v8h11.3c-.8 2.2-2.2 4.2-4.1 5.6l6.2 5.2C37 39.2 44 34 44 24c0-1.3-.1-2.6-.4-3.9z"/></svg>';
?>
<div id="landing">

	<div class="hero" id="hero">
		<div class="hero-sticky">
			<video class="hero-video" id="heroVideo"
				src="<?php echo esc_url( agenturf_video_url() ); ?>"
				poster="<?php echo esc_url( agenturf_poster_url() ); ?>"
				autoplay muted loop playsinline></video>
			<div class="hero-veil" id="heroVeil"></div>
			<div class="hero-inner" id="heroTitle">
				<span class="hero-chip"><?php echo esc_html( $meta['eyebrow'] ); ?></span>
				<h1 class="hero-h1">Le Quinté du jour,<br><em>simulé</em> avant d'être couru</h1>
				<p class="hero-sub">Analyse complète des partants, <?php echo (int) $nbsc; ?> scénarios pondérés par un modèle, et une course animée en direct — relance-la autant de fois que tu veux, chaque arrivée est différente.</p>
				<a class="hero-cta google-cta-like" href="#acces">🏇 Accéder au simulateur</a>
			</div>
			<div class="hero-cue">Fais défiler</div>
		</div>
	</div>

	<section class="land-section">
		<h2 class="land-h2 reveal"><span class="tick"></span>Les outils AgenTurf</h2>
		<p class="land-lead reveal">Tout ce qu'il faut pour lire la course avant tout le monde — mis à jour chaque jour de Quinté+.</p>
		<div class="tools">
			<div class="tool reveal">
				<div class="ico">🏇</div>
				<h3>Simulateur en direct</h3>
				<p>La course animée sur la piste : départ, train, rabattement à la corde, emballage final. Classement en direct et commentaires comme au micro de l'hippodrome.</p>
				<span class="mini">Arrivée différente à chaque lancement</span>
			</div>
			<div class="tool reveal d1">
				<div class="ico">🎯</div>
				<h3><?php echo (int) $nbsc; ?> scénarios pondérés</h3>
				<p>Course de bon sens, coup d'écurie, revanche des poids plume, chaos total… chaque scénario recalibre le modèle avec sa probabilité estimée.</p>
				<span class="mini">Probabilités du modèle</span>
			</div>
			<div class="tool reveal d2">
				<div class="ico">📋</div>
				<h3>Partants décryptés</h3>
				<p>Valeur handicap, poids, corde, musique, style de course et avis entraîneurs — chaque partant analysé en une fiche claire.</p>
				<span class="mini">Mise à jour quotidienne</span>
			</div>
		</div>
		<div class="counters">
			<div class="counter reveal"><b data-count="<?php echo (int) $nb; ?>">0</b><span>partants analysés</span></div>
			<div class="counter reveal d1"><b data-count="<?php echo (int) $nbsc; ?>">0</b><span>scénarios de course</span></div>
			<div class="counter reveal d2"><b>∞</b><span>simulations</span></div>
			<div class="counter reveal d3"><b>100<small>%</small></b><span>gratuit</span></div>
		</div>
	</section>

	<section class="land-section">
		<h2 class="land-h2 reveal"><span class="tick"></span>Comment ça marche</h2>
		<div class="steps">
			<div class="step reveal"><span class="num">1</span><h3>Connecte-toi avec Google</h3><p>Un clic, aucune carte bancaire. Ton compte débloque tous les outils, tous les jours.</p></div>
			<div class="step reveal d1"><span class="num">2</span><h3>Choisis ton scénario</h3><p>Lis l'analyse des partants, puis choisis le scénario de course auquel tu crois.</p></div>
			<div class="step reveal d2"><span class="num">3</span><h3>Lance la simulation</h3><p>Regarde la course se jouer et compare les combinaisons qui reviennent le plus souvent.</p></div>
		</div>
	</section>

	<div class="gatewrap" id="acces">
		<div class="gatecard reveal">
			<h2>La course du jour t'attend<br><em><?php echo esc_html( $meta['title'] ); ?></em></h2>
			<p><?php echo esc_html( $meta['subtitle'] ); ?> — l'accès au simulateur est réservé aux membres. C'est gratuit et immédiat :</p>
			<ul>
				<li>Simulations illimitées, chaque arrivée est différente</li>
				<li>Les <?php echo (int) $nbsc; ?> scénarios du modèle débloqués</li>
				<li>L'analyse complète des <?php echo (int) $nb; ?> partants</li>
				<li>Le Quinté+ du jour, chaque jour</li>
			</ul>
			<br>
			<a class="google-cta" href="<?php echo esc_url( $login ); ?>" rel="nofollow"><?php echo $google_svg; // phpcs:ignore ?> Continuer avec Google</a>
			<p class="gate-note">Gratuit. Aucune carte bancaire. Juste ton compte Google.</p>
		</div>
	</div>

	<footer class="land-footer">
		<hr>
		Outil d'analyse et de divertissement. Les probabilités affichées sont des estimations issues du modèle, pas des cotes officielles. Jouer comporte des risques : ne mise que ce que tu peux te permettre de perdre.
	</footer>

</div>
